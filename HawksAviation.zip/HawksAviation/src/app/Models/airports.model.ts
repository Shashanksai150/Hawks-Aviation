export class Airports{
 airportID! : string;
 name!: string;
 city!: string;
 country!: string
}

