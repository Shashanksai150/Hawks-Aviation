export class Bookings{
bookingID: Number = 0;
flightNo: Number = 0;
customerID: Number = 0;
seats: Number = 0;
arrival!: Date;
departure!: Date;
bookingAmount!: Number;
status!: string;
isCancelled!: boolean;
isCheckedIn!: boolean;
outdated!: boolean;
}
